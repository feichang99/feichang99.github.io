@echo off
setlocal EnableDelayedExpansion

set "OUTPUT=Subnet_Speed_Test.txt"
set "TMP_SPD=%temp%\ipv6_curl_tmp.txt"

echo ========================================
echo Scanning Cloudflare Subnets for CMCC
echo ========================================

echo Subnet Speed Rank > "%OUTPUT%"
echo Speed (KB/s)  ^|  Subnet Target >> "%OUTPUT%"
echo ======================================== >> "%OUTPUT%"

set "TEST_NODES=2405:b500::1 2405:b500:8000::1 2606:4700:3031::1 2606:4700:3032::1 2606:4700:3033::1 2606:4700:3034::1 2606:4700:3035::1 2606:4700:8400::1 2a06:98c1:3120::1 2a06:98c1:3121::1 2c0f:f248:3000::1 2606:4700:4700::1111"

for %%I in (%TEST_NODES%) do (
    echo Testing Subnet: [%%I]
    
    type nul > "!TMP_SPD!"
    curl -6 -s -w "%%{speed_download}" -A "Mozilla/5.0" -o NUL --connect-timeout 2 --max-time 4 --resolve speed.cloudflare.com:443:[%%I] https://speed.cloudflare.com/__down?bytes=2000000 > "!TMP_SPD!" 2>nul
    
    set "SPD=0"
    for /f "usebackq delims=., " %%A in ("!TMP_SPD!") do set "SPD=%%A"
    set /a KB=!SPD! / 1024 2>nul
    
    echo Result: !KB! KB/s
    echo ----------------------------------------
    
    if !KB! GTR 0 (
        echo !KB! KB/s    ^|  %%I >> "%OUTPUT%"
    )
)

if exist "!TMP_SPD!" del "!TMP_SPD!" 2>nul

echo ========================================
echo Done! Check %OUTPUT% to see results.
pause