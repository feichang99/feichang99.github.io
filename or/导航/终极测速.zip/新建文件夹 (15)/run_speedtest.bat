@echo off
setlocal EnableDelayedExpansion

set "INPUT=ip.txt"
set "OUTPUT=IPv6_Speed.txt"
set "TMP_SPD=%temp%\ipv6_curl_tmp.txt"

if not exist "%INPUT%" (
    echo [ERROR] ip.txt not found!
    pause
    exit /b
)

echo Starting IPv6 speed test...
echo ======================================== > "%OUTPUT%"
echo Speed (KB/s)  ^|  IPv6 Address >> "%OUTPUT%"
echo ======================================== >> "%OUTPUT%"

for /f "usebackq delims=" %%i in ("%INPUT%") do (
    set "IP=%%i"
    set "IP=!IP:[=!"
    set "IP=!IP:]=!"
    
    if not "!IP!"=="" (
        echo Testing: [!IP!]
        
        type nul > "!TMP_SPD!"
        
        curl -6 -s -w "%%{speed_download}" -A "Mozilla/5.0" -o NUL --connect-timeout 2 --max-time 5 --resolve speed.cloudflare.com:443:[!IP!] https://speed.cloudflare.com/__down?bytes=2000000 > "!TMP_SPD!" 2>nul
        
        set "SPD=0"
        for /f "usebackq delims=., " %%A in ("!TMP_SPD!") do (
            set "SPD=%%A"
        )
        
        set /a KB=!SPD! / 1024 2>nul
        
        echo Result: !KB! KB/s
        echo ----------------------------------------
        
        echo !KB! KB/s    ^|  !IP! >> "%OUTPUT%"
    )
)

if exist "!TMP_SPD!" del "!TMP_SPD!" 2>nul

echo ========================================
echo Done! Check %OUTPUT% for results.
pause