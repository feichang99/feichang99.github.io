@echo off
setlocal EnableDelayedExpansion

set "OUTPUT=IPv6_Fast_Results.txt"
set "TMP_SPD=%temp%\ipv6_curl_tmp.txt"
set "SUBNET=2606:4700:20::"

echo ========================================
echo  Auto Speedtest for Subnet %SUBNET%
echo ========================================

echo Fast IPv6 Nodes (Sorted by Scan Order) > "%OUTPUT%"
echo Speed (KB/s)  ^|  IPv6 Address >> "%OUTPUT%"
echo ======================================== >> "%OUTPUT%"

:: �Զ�ѭ������ 1 �� 200 �� IP
for /l %%N in (1,1,200) do (
    set "IP=%SUBNET%%%N"
    echo Testing: [!IP!]
    
    type nul > "!TMP_SPD!"
    
    curl -6 -s -w "%%{speed_download}" -A "Mozilla/5.0" -o NUL --connect-timeout 2 --max-time 4 --resolve speed.cloudflare.com:443:[!IP!] https://speed.cloudflare.com/__down?bytes=2000000 > "!TMP_SPD!" 2>nul
    
    set "SPD=0"
    for /f "usebackq delims=., " %%A in ("!TMP_SPD!") do set "SPD=%%A"
    set /a KB=!SPD! / 1024 2>nul
    
    echo Result: !KB! KB/s
    echo ----------------------------------------
    
    :: ֻ�����ٶȵĽڵ�д����
    if !KB! GTR 0 (
        echo !KB! KB/s    ^|  !IP! >> "%OUTPUT%"
    )
)

if exist "!TMP_SPD!" del "!TMP_SPD!" 2>nul

echo.
echo ========================================
echo Done! Valid fast IPs saved to %OUTPUT%
pause