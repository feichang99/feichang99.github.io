@echo off
setlocal EnableDelayedExpansion

set "OUTPUT=Subnet_Asia_Test.txt"
set "TMP_SPD=%temp%\ipv6_curl_tmp.txt"

echo ========================================
echo Scanning Asia-Pacific CMI IPv6 Subnets
echo ========================================

echo Speed (KB/s)  ^|  Subnet Target > "%OUTPUT%"
echo ======================================== >> "%OUTPUT%"

set "TEST_NODES=2405:8100:2000::1 2a06:98c0:3600::1 2a06:98c1:5000::1 2a09:bac0:1000::1 2606:4700:10::1 2606:4700:4700::1111 2606:4700:8400::1 2606:4700:100::1"

for %%I in (%TEST_NODES%) do (
    echo Testing: [%%I]
    type nul > "!TMP_SPD!"
    curl -6 -s -w "%%{speed_download}" -A "Mozilla/5.0" -o NUL --connect-timeout 2 --max-time 5 --resolve speed.cloudflare.com:443:[%%I] https://speed.cloudflare.com/__down?bytes=2000000 > "!TMP_SPD!" 2>nul
    
    set "SPD=0"
    for /f "usebackq delims=., " %%A in ("!TMP_SPD!") do set "SPD=%%A"
    set /a KB=!SPD! / 1024 2>nul
    
    echo Result: !KB! KB/s
    echo ----------------------------------------
    if !KB! GTR 0 echo !KB! KB/s    ^|  %%I >> "%OUTPUT%"
)

if exist "!TMP_SPD!" del "!TMP_SPD!" 2>nul
echo Done!
pause