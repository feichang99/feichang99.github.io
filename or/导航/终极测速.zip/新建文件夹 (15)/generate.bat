@echo off
set "OUT=ip.txt"
set "SUBNET=2606:4700:20::"

echo sc 1000  IP...
type nul > "%OUT%"

for /l %%i in (1,1,1000) do (
    echo %SUBNET%%%i>>"%OUT%"
)

echo  %OUT%
pause