export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url)
    
    // 強制將請求導向 Cloudflare DNS 的標準 DoH 端點
    const upstream = "https://cloudflare-dns.com/dns-query"
    
    const newUrl = new URL(upstream)
    newUrl.search = url.search

    // 複製請求並確保 Method 與 Body 正確傳遞
    const newRequest = new Request(newUrl, {
      method: request.method,
      headers: request.headers,
      body: request.method === 'GET' || request.method === 'HEAD' ? null : request.body,
      redirect: 'follow'
    })

    try {
      const response = await fetch(newRequest)
      let newResponse = new Response(response.body, response)
      newResponse.headers.set('Access-Control-Allow-Origin', '*')
      return newResponse
    } catch (err) {
      return new Response(`DoH Proxy Error: ${err.message}`, { status: 500 })
    }
  }
}