#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Cloudflare AP 批量检测
支持：
1. IPv4：101.108.49.121:443#TH
2. IPv6：[2400:c620:22:22e::a]:443
3. 测速报告：... | IP地址: [2400:c620:22:22e::a]:443 | 地区: HKG 香港

把整段测速结果粘贴到 AP_TEXT 中即可。
只使用 Python 标准库，无需安装第三方模块。
"""

import concurrent.futures
import ipaddress
import re
import socket
import ssl
import time
from pathlib import Path

TEST_HOST = "www.cloudflare.com"
TEST_PATH = "/cdn-cgi/trace"
TIMEOUT = 5
MAX_WORKERS = 80

# 把 AP 或完整测速报告粘贴在下面，支持混合 IPv4、IPv6。
AP_TEXT = r"""
NO.1 | 流媒体网速: 27.05 MB/s | IP地址: [2a0e:97c0:3f0:1::156b]:443 | 地区: HKG 香港
NO.2 | 流媒体网速: 26.22 MB/s | IP地址: [2400:c620:32:4d::a]:443 | 地区: HKG 香港
NO.3 | 流媒体网速: 25.34 MB/s | IP地址: [2400:c620:22:30d::a]:443 | 地区: HKG 香港
NO.4 | 流媒体网速: 22.83 MB/s | IP地址: [2001:df1:7880:101::a0c]:443 | 地区: HKG 香港
NO.5 | 流媒体网速: 21.20 MB/s | IP地址: [2a0e:97c0:3f0:1::156a]:443 | 地区: HKG 香港
NO.6 | 流媒体网速: 17.43 MB/s | IP地址: [2001:df1:7880:100::1c9b]:8443 | 地区: HKG 香港
NO.7 | 流媒体网速: 17.10 MB/s | IP地址: [2400:c620:29:b8::a]:443 | 地区: HKG 香港
NO.8 | 流媒体网速: 16.65 MB/s | IP地址: [2401:b60:5:203b:bbb6:d5af:bfd8:18a5]:443 | 地区: HKG 香港
NO.9 | 流媒体网速: 16.58 MB/s | IP地址: [2001:df1:7880:6::16e]:2087 | 地区: HKG 香港
NO.10 | 流媒体网速: 16.19 MB/s | IP地址: [2001:df1:7880:100::594]:443 | 地区: HKG 香港
NO.11 | 流媒体网速: 16.15 MB/s | IP地址: [2603:c024:15:4966:0:f165:9637:c2e9]:8443 | 地区: ICN 韩国首尔
NO.12 | 流媒体网速: 16.13 MB/s | IP地址: [2603:c024:15:ef00:0:7a69:2f33:68a1]:8443 | 地区: ICN 韩国首尔
NO.13 | 流媒体网速: 12.60 MB/s | IP地址: [2001:df1:7880:6::f2]:2083 | 地区: HKG 香港
NO.14 | 流媒体网速: 6.58 MB/s | IP地址: [2407:cdc0:f004:bcb6:992b:dc57:1db9:543c]:443 | 地区: TPE 台湾 桃园
NO.15 | 流媒体网速: 5.83 MB/s | IP地址: [240d:c000:f000:a000:96dc:dd4:2a30:0]:443 | 地区: HKG 香港
NO.16 | 流媒体网速: 5.77 MB/s | IP地址: [2401:b60:5:af2f:9dde:8832:7be9:3d72]:443 | 地区: HKG 香港
NO.17 | 流媒体网速: 5.24 MB/s | IP地址: [2a0e:97c0:7d7:e93:8925:f34b:801a:dddf]:8443 | 地区: HKG 香港
NO.18 | 流媒体网速: 3.76 MB/s | IP地址: [2401:b60:e00e:702c:1234:5678:9abc:def0]:8443 | 地区: HKG 香港
NO.19 | 流媒体网速: 2.61 MB/s | IP地址: [2407:cdc0:f006:ad80:c8e0:2304:8f61:b2a3]:443 | 地区: TPE 台湾 桃园
NO.20 | 流媒体网速: 1.43 MB/s | IP地址: [2401:b60:5:8cab:6745:f127:3e9e:b231]:443 | 地区: HKG 香港
NO.21 | 流媒体网速: 1.25 MB/s | IP地址: [2400:c620:22:245::a]:443 | 地区: HKG 香港
NO.22 | 流媒体网速: 1.22 MB/s | IP地址: [2a14:4900:2207:fe2::e17]:443 | 地区: HKG 香港
NO.23 | 流媒体网速: 685 KB/s | IP地址: [2407:cdc0:f004:281b:a28f:6af0:3563:b190]:443 | 地区: TPE 台湾 桃园






"""
# 匹配 [IPv6]:端口，或 IPv4:端口；不把未加方括号的 IPv6 猜成带端口格式。
BRACKETED_IPV6_RE = re.compile(r"\[([0-9a-fA-F:.]+)\]\s*:\s*(\d{1,5})")
IPV4_PORT_RE = re.compile(
    r"(?<![\w.])((?:\d{1,3}\.){3}\d{1,3})\s*:\s*(\d{1,5})(?!\d)"
)


def valid_endpoint(ip_text, port_text):
    ip_obj = ipaddress.ip_address(ip_text)
    port = int(port_text)
    if not 1 <= port <= 65535:
        raise ValueError("端口超出 1–65535")
    if ip_obj.version == 6:
        endpoint = f"[{ip_obj.compressed}]:{port}"
    else:
        endpoint = f"{ip_obj.compressed}:{port}"
    return endpoint, str(ip_obj), port


def extract_ap_line(line):
    """从一行普通 AP 或测速报告中提取 IP、端口及可选地区标记。"""
    line = line.strip()
    if not line or line.startswith("//"):
        return None

    # 优先处理标准的 [IPv6]:port。
    match = BRACKETED_IPV6_RE.search(line)
    if match:
        endpoint, ip_text, port = valid_endpoint(match.group(1), match.group(2))
    else:
        # 其次处理 IPv4:port。
        match = IPV4_PORT_RE.search(line)
        if not match:
            return None
        endpoint, ip_text, port = valid_endpoint(match.group(1), match.group(2))

    # 普通格式中的 #TH 等标记原样保留；
    # 测速报告中的“地区: HKG 香港”也保留在输出中。
    marker = ""
    hash_match = re.search(r"#\s*([^\s|]+)", line)
    if hash_match:
        marker = "#" + hash_match.group(1)
    else:
        region_match = re.search(r"地区\s*[:：]\s*([^|]+)", line)
        if region_match:
            region = region_match.group(1).strip()
            if region:
                marker = "#" + region

    return {
        "raw": endpoint + marker,
        "ip": ip_text,
        "port": port,
    }


def test_ap(item):
    start = time.perf_counter()
    try:
        raw_sock = socket.create_connection(
            (item["ip"], item["port"]), timeout=TIMEOUT
        )
        context = ssl.create_default_context()

        with raw_sock:
            with context.wrap_socket(
                raw_sock, server_hostname=TEST_HOST
            ) as tls:
                tls.settimeout(TIMEOUT)
                request = (
                    f"GET {TEST_PATH} HTTP/1.1\r\n"
                    f"Host: {TEST_HOST}\r\n"
                    "User-Agent: AP-Checker/1.1\r\n"
                    "Accept: */*\r\n"
                    "Connection: close\r\n\r\n"
                )
                tls.sendall(request.encode("ascii"))

                response = bytearray()
                while len(response) < 16384:
                    chunk = tls.recv(min(4096, 16384 - len(response)))
                    if not chunk:
                        break
                    response.extend(chunk)
                    if b"\r\n\r\n" in response and b"ip=" in response:
                        break

        elapsed = (time.perf_counter() - start) * 1000
        header, _, body = bytes(response).partition(b"\r\n\r\n")
        first_line = header.split(b"\r\n", 1)[0].decode(
            "latin1", "replace"
        )
        parts = first_line.split()
        status = (
            int(parts[1])
            if len(parts) >= 2 and parts[1].isdigit()
            else 0
        )
        body_text = body.decode("utf-8", "replace")
        success = (
            status == 200
            and "fl=" in body_text
            and "ip=" in body_text
        )

        detail = first_line if first_line else "无有效 HTTP 响应"
        return item, success, elapsed, detail

    except Exception as exc:
        elapsed = (time.perf_counter() - start) * 1000
        return item, False, elapsed, f"{type(exc).__name__}: {exc}"


def main():
    print("=" * 64)
    print("Cloudflare AP IPv4 / IPv6 批量检测")
    print(f"测试目标：{TEST_HOST}{TEST_PATH}")
    print("=" * 64)

    items = []
    seen = set()

    for line_no, line in enumerate(AP_TEXT.splitlines(), 1):
        try:
            item = extract_ap_line(line)
            if item:
                key = (item["ip"], item["port"])
                if key not in seen:
                    seen.add(key)
                    items.append(item)
        except Exception as exc:
            print(f"[格式错误] 第 {line_no} 行：{exc} | {line.strip()}")

    if not items:
        print("没有提取到 AP。请检查 AP_TEXT 中粘贴的格式。")
        input("按回车退出...")
        return

    print(
        f"提取到 {len(items)} 个不同 AP；"
        f"并发数 {MAX_WORKERS}；超时 {TIMEOUT} 秒。\n"
    )

    results = []
    with concurrent.futures.ThreadPoolExecutor(
        max_workers=MAX_WORKERS
    ) as pool:
        futures = [pool.submit(test_ap, item) for item in items]
        for future in concurrent.futures.as_completed(futures):
            result = future.result()
            results.append(result)
            item, ok, elapsed, detail = result
            label = "可用" if ok else "不可用"
            print(f"[{label}] {item['raw']}  {elapsed:.0f} ms  {detail}")

    # 按输入顺序写入文件
    order = {
        (item["ip"], item["port"]): index
        for index, item in enumerate(items)
    }
    results.sort(
        key=lambda result: order[(result[0]["ip"], result[0]["port"])]
    )

    good = [r for r in results if r[1]]
    bad = [r for r in results if not r[1]]

    Path("可用AP.txt").write_text(
        "\n".join(r[0]["raw"] for r in good) + ("\n" if good else ""),
        encoding="utf-8",
    )
    Path("不可用AP.txt").write_text(
        "\n".join(r[0]["raw"] for r in bad) + ("\n" if bad else ""),
        encoding="utf-8",
    )

    print("\n" + "=" * 64)
    print(f"检测完成：总数 {len(items)}，可用 {len(good)}，不可用 {len(bad)}")
    print("已生成：可用AP.txt、不可用AP.txt")
    print("说明：检测方式与此前版本相同；本次主要更新 IPv4/IPv6 格式提取。")
    input("\n按回车退出...")


if __name__ == "__main__":
    main()
